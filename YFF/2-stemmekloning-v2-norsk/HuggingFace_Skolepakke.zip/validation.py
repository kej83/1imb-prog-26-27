"""Input limits for short classroom voice-cloning demonstrations."""

import math
from pathlib import Path

LANGUAGES = {
    "Norsk (anbefalt)": "no",
    "Norsk bokmål": "nb",
    "Norsk nynorsk": "nn",
    "English": "en",
}
MAX_TEXT_CHARACTERS = 280
MAX_TEXT_WORDS = 40


def validate_text_inputs(reference_text, text, language, seed, consent):
    if consent is not True:
        raise ValueError("Bekreft at stemmen er din egen, eller at du har tillatelse til å bruke den.")
    reference_text = str(reference_text or "").strip()
    text = str(text or "").strip()
    if not reference_text or len(reference_text) > 600:
        raise ValueError("Skriv nøyaktig det som sies i opptaket, maksimalt 600 tegn.")
    if not text or len(text) > MAX_TEXT_CHARACTERS or len(text.split()) > MAX_TEXT_WORDS:
        raise ValueError("Skriv mellom ett og førti ord, maksimalt 280 tegn.")
    if any(character in text + reference_text for character in "[]<>"):
        raise ValueError("Bruk vanlig tekst uten kontrolltagger eller klammeparenteser.")
    if language not in LANGUAGES:
        raise ValueError("Velg norsk eller engelsk fra språklisten.")
    try:
        number = float(seed)
    except (ValueError, TypeError, OverflowError):
        raise ValueError("Seed må være et heltall fra null til 2147483647.") from None
    if not math.isfinite(number) or not number.is_integer() or not 0 <= number <= 2147483647:
        raise ValueError("Seed må være et heltall fra null til 2147483647.")
    return {
        "reference_text": reference_text,
        "text": text,
        "language": LANGUAGES[language],
        "seed": int(number),
        "output_seconds": max(2.0, min(18.0, len(text.split()) / 2.3)),
    }


def validate_audio_path(path, cache_directory):
    if not path:
        raise ValueError("Last opp eller spill inn en referansestemme først.")
    audio = Path(path).resolve()
    if not audio.is_relative_to(Path(cache_directory).resolve()) or not audio.is_file():
        raise ValueError("Bruk et lydopptak lastet opp gjennom appen.")
    if audio.stat().st_size > 10 * 1024 * 1024:
        raise ValueError("Referanseopptaket er for stort. Bruk et kort opptak.")
    return audio


def validate_audio_metadata(frames, sample_rate, channels):
    if sample_rate <= 0 or channels not in {1, 2}:
        raise ValueError("Opptaket må ha én eller to lydkanaler og gyldig samplingsfrekvens.")
    seconds = frames / sample_rate
    if not 10.0 <= seconds <= 15.0:
        raise ValueError("Referanseopptaket må vare mellom ti og femten sekunder.")
    return seconds
