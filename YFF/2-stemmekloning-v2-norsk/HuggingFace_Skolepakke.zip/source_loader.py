"""Load the same application source as the supplied SECourses installer."""

from __future__ import annotations

import hashlib
import io
from pathlib import Path, PurePosixPath
import sys
import zipfile

import requests

APP_REVISION = "832d8546bd759c5e9e4ba71e1c42fb9a08aaa329"
APP_ARCHIVE_SHA256 = "221ec9786880ec15a5571b6f9d53efdeb5d0e5908a03649dce940a6be8437e8c"
APP_ARCHIVE_URL = (
    "https://codeload.github.com/FurkanGozukara/"
    f"Premium_IndexTTS2_SECourses/zip/{APP_REVISION}"
)
MAX_ARCHIVE_BYTES = 64 * 1024 * 1024


def extract_application(archive: bytes, destination: Path) -> None:
    """Extract only Python source; reject corrupt or unexpected archives."""
    if hashlib.sha256(archive).hexdigest() != APP_ARCHIVE_SHA256:
        raise RuntimeError("Application source checksum mismatch; download rejected.")
    prefix = f"Premium_IndexTTS2_SECourses-{APP_REVISION}/"
    with zipfile.ZipFile(io.BytesIO(archive)) as bundle:
        for member in bundle.infolist():
            if member.is_dir() or not member.filename.startswith(prefix):
                continue
            relative = PurePosixPath(member.filename[len(prefix):])
            if not relative.parts or relative.parts[0] != "indextts" or relative.suffix != ".py":
                continue
            if relative.is_absolute() or ".." in relative.parts or "\\" in str(relative):
                raise RuntimeError("Unsafe application archive path.")
            target = destination.joinpath(*relative.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(bundle.read(member))


def ensure_application(cache_directory: Path) -> Path:
    destination = cache_directory / APP_REVISION
    marker = destination / ".verified-source"
    if not marker.is_file() or marker.read_text(encoding="utf-8") != APP_ARCHIVE_SHA256:
        print("Downloading pinned Ultimate TTS application source...", flush=True)
        archive = bytearray()
        with requests.get(APP_ARCHIVE_URL, stream=True, timeout=(15, 120)) as response:
            response.raise_for_status()
            for block in response.iter_content(chunk_size=1024 * 1024):
                archive.extend(block)
                if len(archive) > MAX_ARCHIVE_BYTES:
                    raise RuntimeError("Application source download exceeds the size limit.")
        extract_application(bytes(archive), destination)
        required = destination / "indextts/backends/omnivoice.py"
        if not required.is_file():
            raise RuntimeError("The application archive does not contain the OmniVoice backend.")
        marker.write_text(APP_ARCHIVE_SHA256, encoding="utf-8")
    sys.path.insert(0, str(destination))
    return destination
