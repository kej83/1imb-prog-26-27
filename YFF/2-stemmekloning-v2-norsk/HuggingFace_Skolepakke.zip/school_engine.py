"""A ZeroGPU adapter around Ultimate TTS's original OmniVoiceEngine."""

from pathlib import Path

from source_loader import ensure_application

MODEL_REVISION = "c5fdb5ccb189668d56333f77ba2629f4cd7535f4"


def create_engine(root: Path, device: str = "cuda:0"):
    # app.py imports spaces first: ZeroGPU must patch CUDA before torch imports.
    ensure_application(root / ".app_source")
    from huggingface_hub import snapshot_download
    import torch
    from indextts.backends.omnivoice import OmniVoiceEngine

    model_directory = root / ".models"
    snapshot_download(
        "k2-fsa/OmniVoice",
        revision=MODEL_REVISION,
        local_dir=str(model_directory / "omnivoice"),
        allow_patterns=["*.json", "*.safetensors", "*.jinja", "audio_tokenizer/*"],
    )

    class SchoolOmniVoiceEngine(OmniVoiceEngine):
        def _prompt(self, path, settings):
            # The desktop engine saves voice prompts to disk. This shared demo
            # builds a prompt per request and does not keep a voice library.
            if not settings["reference_text"]:
                raise ValueError("Skriv teksten fra referanseopptaket.")
            with torch.inference_mode():
                return self.model.create_voice_clone_prompt(
                    ref_audio=str(path),
                    ref_text=settings["reference_text"],
                    preprocess_prompt=False,
                )

    engine = SchoolOmniVoiceEngine(
        model_dir=str(model_directory),
        runtime={
            "device": device,
            "model_variant": "bf16",
            "gpt_dtype": "bf16" if device.startswith("cuda") else "fp32",
            "attention_backend": "sdpa",
            "use_accel": False,
            "torch_compile_s2mel": False,
        },
    )
    if not {"no", "nb", "nn", "en"}.issubset(engine.model.supported_language_ids()):
        raise RuntimeError("The loaded model lacks the requested language IDs.")
    return engine


def synthesize(engine, payload):
    return engine.infer(
        payload["reference_audio"],
        payload["text"],
        lang=payload["language"],
        seed=payload["seed"],
        omnivoice={
            "mode": "clone",
            "reference_text": payload["reference_text"],
            "num_step": 32,
            "audio_chunk_duration": 12.0,
            "audio_chunk_threshold": 18.0,
            "preprocess_prompt": False,
        },
        text_normalization=False,
        enable_pause_tags=False,
        segmentation_mode="smart",
        max_text_tokens_per_segment=120,
        section_batch_size=1,
        # Bound the amount of GPU work even for unusually slow reference speech.
        target_duration_s=payload["output_seconds"],
        target_duration_mode="natural",
        take_quality_enabled=False,
    )
