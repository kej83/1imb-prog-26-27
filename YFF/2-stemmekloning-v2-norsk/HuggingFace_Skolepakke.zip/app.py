"""Ultimate TTS classroom interface for Hugging Face Gradio + ZeroGPU."""

import spaces  # Must precede torch and every module that imports torch.

import os
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parent
AUDIO_CACHE = ROOT / ".audio_cache"
os.environ["GRADIO_TEMP_DIR"] = str(AUDIO_CACHE)
os.environ.setdefault("HF_HOME", str(ROOT / ".hf_cache"))
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
AUDIO_CACHE.mkdir(parents=True, exist_ok=True)

import gradio as gr
import soundfile as sf

from school_engine import create_engine, synthesize
from validation import (
    LANGUAGES,
    validate_audio_metadata,
    validate_audio_path,
    validate_text_inputs,
)

ENGINE = None


@spaces.GPU(duration=60)
def generate_on_gpu(payload):
    if ENGINE is None:
        raise RuntimeError("Speech model has not been initialized.")
    return synthesize(ENGINE, payload)


def clone_voice(reference_audio, reference_text, text, language, seed, consent):
    # Reject invalid inputs before requesting any of the visitor's GPU quota.
    try:
        payload = validate_text_inputs(reference_text, text, language, seed, consent)
        path = validate_audio_path(reference_audio, AUDIO_CACHE)
        info = sf.info(str(path))
        validate_audio_metadata(info.frames, info.samplerate, info.channels)
    except (ValueError, OSError, sf.LibsndfileError) as error:
        raise gr.Error(str(error)) from None
    payload["reference_audio"] = str(path)
    started = time.perf_counter()
    audio = generate_on_gpu(payload)
    seconds = len(audio[1]) / audio[0]
    return audio, (
        f"Ferdig: {seconds:.1f} sekunder lyd. Tid inkludert eventuell GPU-kø: "
        f"{time.perf_counter() - started:.1f} sekunder. Last ned WAV fra lydspilleren."
    )


def build_demo():
    with gr.Blocks(title="Ultimate TTS – norsk og engelsk", delete_cache=(600, 3600)) as demo:
        gr.Markdown(
            "# Stemmekloning på norsk og engelsk\n"
            "Skoleutgave av **Ultimate TTS** med OmniVoice. Bruk korte tekster. "
            "Resultatet er KI-generert, og uttale og stemmelikhet kan variere."
        )
        with gr.Row():
            with gr.Column():
                reference_audio = gr.Audio(
                    sources=["upload"], type="filepath", format="wav",
                    label="1. Last opp din referansestemme – 10–15 sekunder",
                )
                reference_text = gr.Textbox(
                    label="2. Skriv nøyaktig det som sies i referanseopptaket", lines=3,
                    placeholder="Skriv alle ordene i opptaket, på språket du snakker.",
                )
                language = gr.Dropdown(
                    choices=list(LANGUAGES), value="Norsk (anbefalt)",
                    label="3. Språk for den nye talen",
                )
                text = gr.Textbox(
                    label="4. Ny tekst – maks. 40 ord og 280 tegn", lines=4,
                    placeholder="Hei! Nå tester vi stemmekloning på norsk. Æ, ø og å skal høres tydelig.",
                )
                consent = gr.Checkbox(
                    label="Jeg bruker min egen stemme eller har tillatelse fra personen i opptaket.",
                    value=False,
                )
                with gr.Accordion("Variasjon", open=False):
                    seed = gr.Number(value=42, precision=0, label="Seed – endre for et nytt forsøk")
                button = gr.Button("Lag tale / Generate speech", variant="primary")
            with gr.Column():
                output = gr.Audio(label="KI-generert tale – last ned som WAV", format="wav")
                status = gr.Textbox(label="Status", interactive=False)
                gr.Markdown(
                    "Bruk et tydelig opptak uten musikk. Referanse på samme språk som "
                    "den nye talen gir vanligvis bedre uttale. Skriv tall med bokstaver.\n\n"
                    "Gratis ZeroGPU har kø og en daglig GPU-kvote. Når kvoten er brukt opp, "
                    "må du vente til den blir tilgjengelig igjen.\n\n"
                    "Opptaket sendes til denne Hugging Face-appen for behandling. "
                    "Bruk et opptak som er egnet for skoleoppgaven. Appen bygger ingen "
                    "stemmeliste; midlertidige lydfiler ryddes periodisk."
                )
        button.click(
            clone_voice,
            inputs=[reference_audio, reference_text, text, language, seed, consent],
            outputs=[output, status],
            api_name="clone_voice",
            concurrency_limit=1,
            concurrency_id="voice_generation",
        )
    demo.queue(default_concurrency_limit=1, max_size=8)
    return demo


if __name__ == "__main__":
    # Initialize at module level so ZeroGPU can prepare model CUDA tensors at
    # startup. GPU calculations themselves run only in generate_on_gpu.
    ENGINE = create_engine(ROOT)
    build_demo().launch(
        server_name="0.0.0.0", server_port=7860, share=False,
        max_file_size="10mb", show_error=False,
    )
